import 'package:flutter_riverpod/flutter_riverpod.dart';

final enteredFirstNameProvider = StateProvider<String>((ref) => "");
final enteredLastNameProvider = StateProvider<String>((ref) => "");
final enteredDOBProvider = StateProvider<String>((ref) => "");
final enteredGenderProvider = StateProvider<String>((ref) => "");
final enteredBloodGroupProvider = StateProvider<String>((ref) => "");
final enteredEmailProvider = StateProvider<String>((ref) => "");
final enteredPhoneProvider = StateProvider<String>((ref) => "");
final enteredAddressProvider = StateProvider<String>((ref) => "");
final enteredHeightFeetProvider = StateProvider<String>((ref) => "");
final enteredHeightInchProvider = StateProvider<String>((ref) => "");
final enteredWeightProvider = StateProvider<String>((ref) => "");
