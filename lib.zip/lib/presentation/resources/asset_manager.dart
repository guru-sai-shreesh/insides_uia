const String imagePath = 'assets/images';

class ImageAssets {
  static const String google = '$imagePath/google.svg';
  static const String facebook = '$imagePath/facebook.svg';
  static const String apple = '$imagePath/apple.svg';
  static const String vector = '$imagePath/Vector.png';
  static const String logo = '$imagePath/insides_health_logo.svg';
}
